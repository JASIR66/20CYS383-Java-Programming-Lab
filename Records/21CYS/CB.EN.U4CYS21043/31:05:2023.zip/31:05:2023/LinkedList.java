package com.jasir.amrita.cys.jpl.datastructures;

import java.util.LinkedList;


public class LinkedListExample {

    public static void main(String[] args) {
        LinkedList<String> u21cys = new LinkedList<String>();

        u21cys.add("CB.EN.U4CYS22040");
        u21cys.add("CB.EN.U4CYS22041");
        u21cys.add("CB.EN.U4CYS22042");
        u21cys.add("CB.EN.U4CYS22043");
        u21cys.add("CB.EN.U4CYS22044");

        // Print the contents of the LinkedList
        System.out.println(u21cys);
    }
}
