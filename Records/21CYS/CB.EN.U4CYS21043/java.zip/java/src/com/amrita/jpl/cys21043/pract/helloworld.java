package com.amrita.jpl.cys21043.pract;




/**
 * @author Jasir
 * @version 0.5
 */

public class helloworld {
    /**
     * Main method that prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}